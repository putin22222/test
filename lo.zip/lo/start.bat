@echo off
powershell.exe -ExecutionPolicy Bypass -NoExit -File "%~dp0run.ps1"
